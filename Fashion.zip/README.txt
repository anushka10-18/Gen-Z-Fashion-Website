MERIDIAN V5
- Removed the full AI Fashion Lookbook section.
- Click any product for a large photo + product details.
- Quantity +/- and Add to Cart.
- Working cart drawer with item quantities, remove and total.
- Wishlist drawer for liked products.
- Search now gives live product results and opens matching products.
- Cart/wishlist persist in the browser.
- Existing 360-degree hero remains.
- Product images are embedded in the HTML.
